// ----------------------------------------------------------------------------------------
// Community Library — track community-owned items (books, tools, gear) and who has them
// checked out. Two tables of the space: `library_assets` for items + checkout info, and a
// `members` list — `members.table.jsonl` or a subtype such as `club.members.table.jsonl` —
// the roster Member Manager keeps, which this frame only reads. Each session is bound to one
// list (sessionKv `bound/members`), chosen by an editor. Preferences (org name, borrow
// durations, item types, edit policy) govern the space's one library_assets table, so they
// are one frameSettings row of the space.
// ----------------------------------------------------------------------------------------
import {
  log, serveFileAtPath, pushToInstance, parsePeerInfo, onUiMessage,
  declareTables, table, frameSettings, sessionKv,
  jsonReply, parseJsonBody, sanitizeText, toIntOrNull, wireTableChangeListener,
} from "@frame-core";

declareTables([
  {
    key: "library_assets",
    title: "Library Assets",
    description: "Items the community shares, with current checkout status.",
    schema: [
      { name: "name",                    col_type: "text",    nullable: false },
      { name: "item_type",               col_type: "text",    nullable: false },
      { name: "checked_out_member_id",   col_type: "text",    nullable: true  },
      { name: "checked_out_manual_name", col_type: "text",    nullable: true  },
      { name: "checked_out_at",          col_type: "integer", nullable: true  },
      { name: "borrow_days",             col_type: "integer", nullable: true  },
      { name: "needs_attention",         col_type: "integer", nullable: false, default_val: "0" },
      { name: "notes",                   col_type: "text",    nullable: true  },
    ],
  },
]);

// ----- Which members list: `members` or a subtype `<name>.members`, bound per session -----
// Read here for its name and role columns; Member Manager writes it.
const LIST_NAME = /^([a-z0-9][a-z0-9_-]*\.)*members$/;
const validList = (n: unknown): n is string => typeof n === "string" && n.length <= 64 && LIST_NAME.test(n);
async function boundList(): Promise<string | null> {
  const v = (await sessionKv.get("bound/members"))?.value;
  return validList(v) ? v : null;
}

// ----- Preferences (a frameSettings row of the space) ------------------------------------
type BorrowOption = { label: string; days: number };
type Prefs = {
  org_name: string;
  item_types: string[];
  borrow_options: BorrowOption[];
  default_borrow_days: number;
  owner_only_edit: boolean;
};

const DEFAULT_PREFS: Prefs = {
  org_name: "Community Library",
  item_types: ["Book", "Tool", "Game", "Equipment", "Other"],
  borrow_options: [
    { label: "3 days",  days: 3  },
    { label: "1 week",  days: 7  },
    { label: "2 weeks", days: 14 },
    { label: "1 month", days: 30 },
  ],
  default_borrow_days: 7,
  owner_only_edit: false,
};

const PREFS_KEY = "community_library_prefs";

function clonePrefs(p: Prefs): Prefs {
  return {
    org_name: p.org_name,
    item_types: [...p.item_types],
    borrow_options: p.borrow_options.map((o) => ({ label: o.label, days: o.days })),
    default_borrow_days: p.default_borrow_days,
    owner_only_edit: p.owner_only_edit,
  };
}

async function getPrefs(sfi_id: string): Promise<Prefs> {
  const p = await frameSettings(sfi_id).get<Prefs>(PREFS_KEY);
  if (!p) return clonePrefs(DEFAULT_PREFS);
  const itemTypes = Array.isArray(p.item_types) && p.item_types.length > 0
    ? p.item_types.map(String) : [...DEFAULT_PREFS.item_types];
  const borrowOptions = Array.isArray(p.borrow_options) && p.borrow_options.length > 0
    ? p.borrow_options
        .map((o) => ({ label: String((o as BorrowOption).label ?? ""), days: Number((o as BorrowOption).days) }))
        .filter((o) => o.label && Number.isFinite(o.days) && o.days > 0)
    : [...DEFAULT_PREFS.borrow_options];
  return {
    org_name: typeof p.org_name === "string" && p.org_name ? p.org_name : DEFAULT_PREFS.org_name,
    item_types: itemTypes,
    borrow_options: borrowOptions.length > 0 ? borrowOptions : [...DEFAULT_PREFS.borrow_options],
    default_borrow_days: Number.isFinite(Number(p.default_borrow_days)) && Number(p.default_borrow_days) > 0
      ? Number(p.default_borrow_days)
      : (borrowOptions[0]?.days ?? DEFAULT_PREFS.default_borrow_days),
    owner_only_edit: !!p.owner_only_edit,
  };
}

async function setPrefs(sfi_id: string, next: Prefs): Promise<void> {
  await frameSettings(sfi_id).set(PREFS_KEY, next);
}

// ----- Helpers --------------------------------------------------------------------------
// Writes are editor-only. Never gate on is_sfi_member — a Viewer-role member would slip
// through and be able to edit the library.
function canEdit(peer: ReturnType<typeof parsePeerInfo>, prefs: Prefs): boolean {
  if (prefs.owner_only_edit) return peer.is_owner;
  return peer.is_sfi_editor;
}

type AssetRow = Record<string, unknown> & { _row_id: string; _created_at: number };
type AssetStatus = "available" | "checked_out" | "overdue" | "issue";

function dueAt(checkedOutAt: number | null, borrowDays: number | null): number | null {
  if (!checkedOutAt || !borrowDays) return null;
  return checkedOutAt + borrowDays * 86400000;
}

function computeStatus(row: AssetRow, now: number): AssetStatus {
  if (Number(row.needs_attention) === 1) return "issue";
  const checkedOutAt = toIntOrNull(row.checked_out_at);
  const borrowDays = toIntOrNull(row.borrow_days);
  if (!checkedOutAt) return "available";
  const due = dueAt(checkedOutAt, borrowDays);
  if (due !== null && now > due) return "overdue";
  return "checked_out";
}

// ----- Shared write logic ---------------------------------------------------------------
// Every mutation, whether it arrives as an HTTP POST or over the tether
// (frame.busSend → onUiMessage), runs through here. `op` is the API path minus the
// leading "api/" ("asset", "asset/checkout", "settings", …). Role gates live here so the
// two entry points never drift. Item writes broadcast via the wired assets_changed listener;
// settings and a new binding push settings_changed.
type WriteResult = { status: number; body: Record<string, unknown> | null };

async function handleWrite(
  sfi_id: string,
  op: string,
  v: Record<string, unknown> | null,
  peer: ReturnType<typeof parsePeerInfo>,
): Promise<WriteResult> {
  const prefs = await getPrefs(sfi_id);

  if (op === "bind") {
    if (!peer.is_sfi_editor) return { status: 403, body: { error: "editors only" } };
    const name = v?.list;
    if (!validList(name)) return { status: 400, body: { error: "a members list is named members or <name>.members" } };
    await sessionKv.put("bound/members", name);
    pushToInstance(sfi_id, { type: "settings_changed" });
    return { status: 200, body: { bound: name } };
  }

  if (op === "settings") {
    if (!peer.is_owner) return { status: 403, body: { error: "only the frame owner can change settings" } };
    if (!v) return { status: 400, body: { error: "invalid JSON" } };
    const org_name = sanitizeText(v.org_name, 120) || DEFAULT_PREFS.org_name;
    const itemTypesIn: unknown[] = Array.isArray(v.item_types) ? v.item_types : [];
    const item_types = Array.from(new Set(itemTypesIn.map((t: unknown) => sanitizeText(t, 80)).filter((t: string) => t.length > 0)));
    if (item_types.length === 0) return { status: 400, body: { error: "at least one item type is required" } };
    const borrowIn: unknown[] = Array.isArray(v.borrow_options) ? v.borrow_options : [];
    const borrow_options = borrowIn
      .map((o: unknown) => ({ label: sanitizeText((o as BorrowOption).label, 40), days: toIntOrNull((o as BorrowOption).days) ?? 0 }))
      .filter((o: { label: string; days: number }) => o.label.length > 0 && o.days > 0);
    if (borrow_options.length === 0) return { status: 400, body: { error: "at least one borrow option is required" } };
    const requestedDefault = toIntOrNull(v.default_borrow_days);
    const days = borrow_options.map((o) => o.days);
    const default_borrow_days = requestedDefault && days.includes(requestedDefault) ? requestedDefault : days[0];
    const next: Prefs = {
      org_name, item_types, borrow_options, default_borrow_days,
      owner_only_edit: !!v.owner_only_edit,
    };
    await setPrefs(sfi_id, next);
    pushToInstance(sfi_id, { type: "settings_changed" });
    return { status: 200, body: { prefs: next } };
  }

  if (!canEdit(peer, prefs)) return { status: 403, body: { error: "editing is restricted" } };
  const assets = table("library_assets", sfi_id);
  // An id that names no item is refused, never created (upsert would phantom-create it).
  const named = v?.row_id ? String(v.row_id) : "";
  if (named && !(await assets.get(named))) return { status: 404, body: { error: "item not found" } };

  if (op === "asset") {
    if (!v) return { status: 400, body: { error: "invalid JSON" } };
    const name = sanitizeText(v.name, 200);
    const itemType = sanitizeText(v.item_type, 80);
    const notes = sanitizeText(v.notes, 1000);
    if (!name) return { status: 400, body: { error: "name required" } };
    if (!itemType) return { status: 400, body: { error: "item_type required" } };
    if (!prefs.item_types.includes(itemType)) return { status: 400, body: { error: "item_type not in allowed list" } };
    const rowId = v.row_id ? String(v.row_id) : null;
    const { row_id } = await assets.upsert(rowId, {
      name, item_type: itemType, notes,
      ...(rowId ? {} : { needs_attention: 0 }),
    });
    return { status: 200, body: { row_id } };
  }

  if (op === "asset/delete") {
    const rowId = String(v?.row_id ?? "");
    if (!rowId) return { status: 400, body: { error: "row_id required" } };
    await assets.delete(rowId);
    return { status: 204, body: null };
  }

  if (op === "asset/checkout") {
    if (!v) return { status: 400, body: { error: "invalid JSON" } };
    const rowId = String(v.row_id ?? "");
    if (!rowId) return { status: 400, body: { error: "row_id required" } };
    const memberId = sanitizeText(v.member_id, 100);
    const manualName = sanitizeText(v.manual_name, 200);
    if (!memberId && !manualName) return { status: 400, body: { error: "member_id or manual_name required" } };
    const borrowDays = toIntOrNull(v.borrow_days) ?? prefs.default_borrow_days;
    const allowedDays = prefs.borrow_options.map((o) => o.days);
    if (!allowedDays.includes(borrowDays)) {
      return { status: 400, body: { error: "borrow_days not in allowed list" } };
    }
    const checkedOutAt = toIntOrNull(v.checked_out_at) ?? Date.now();
    await assets.upsert(rowId, {
      checked_out_member_id: memberId,
      checked_out_manual_name: memberId ? "" : manualName,
      checked_out_at: checkedOutAt,
      borrow_days: borrowDays,
    });
    return { status: 200, body: { row_id: rowId } };
  }

  if (op === "asset/checkin") {
    const rowId = String(v?.row_id ?? "");
    if (!rowId) return { status: 400, body: { error: "row_id required" } };
    await assets.upsert(rowId, {
      checked_out_member_id: "",
      checked_out_manual_name: "",
      checked_out_at: null,
      borrow_days: null,
    });
    return { status: 200, body: { row_id: rowId } };
  }

  if (op === "asset/attention") {
    if (!v) return { status: 400, body: { error: "invalid JSON" } };
    const rowId = String(v.row_id ?? "");
    if (!rowId) return { status: 400, body: { error: "row_id required" } };
    const flag = v.needs_attention ? 1 : 0;
    const update: Record<string, unknown> = { needs_attention: flag };
    if (typeof v.notes !== "undefined") update.notes = sanitizeText(v.notes, 1000);
    await assets.upsert(rowId, update);
    return { status: 200, body: { row_id: rowId } };
  }

  return { status: 404, body: { error: "Not found.", code: "NOT_FOUND" } };
}

// ----- Bus dispatcher — the frontend's write path (frame.busSend → BusUiToFrame) --------
// `peer` is the sender's platform-resolved identity, same shape as parsePeerInfo; role
// gates live inside handleWrite. Denials are logged, not answered — a legitimate client
// never sends a write it isn't allowed to make. Resulting state reaches every viewer
// (sender included) via the assets_changed push / settings_changed.
onUiMessage(async (sfiId, data, peer) => {
  if (!sfiId || typeof data !== "object" || data === null) return;
  const d = data as Record<string, unknown>;
  if (typeof d.op !== "string" || !d.op) return;
  wireTableChangeListener("library_assets", sfiId, "assets_changed");
  const r = await handleWrite(sfiId, d.op, d, peer);
  if (r.status >= 400) log(`community library: bus op ${d.op} → ${r.status} (${JSON.stringify(r.body)})`);
});

// ----- HTTP handler ---------------------------------------------------------------------
self.onNetworkRequest = async function (replyPort, reqPath, method, _headers, query, body, cookies) {
  const peer = parsePeerInfo(query, cookies);

  wireTableChangeListener("library_assets", peer.sfi_id, "assets_changed");
  const assets = table("library_assets", peer.sfi_id);
  const list = await boundList();
  const roster = async () => list ? (await table(list, peer.sfi_id).query({ limit: 1000 })).rows as Record<string, unknown>[] : [];
  const prefs = await getPrefs(peer.sfi_id);
  const editable = canEdit(peer, prefs);
  const now = Date.now();

  if (reqPath === "/api/state" && method === "GET") {
    return jsonReply(replyPort, 200, {
      prefs,
      viewer: {
        user_name: peer.user_name || "anon",
        is_owner: peer.is_owner,
        is_anon: peer.is_anon,
      },
      can_edit: editable,
      bound: list,
      can_bind: peer.is_sfi_editor,
      now,
    });
  }

  if (reqPath === "/api/members" && method === "GET") {
    if (peer.is_anon) return jsonReply(replyPort, 200, { rows: [] });
    const rows = await roster();
    rows.sort((a, b) => String(a.name).localeCompare(String(b.name)));
    const slim = rows.map((r: Record<string, unknown>) => ({
      _row_id: r._row_id, name: r.name, role: r.role,
    }));
    return jsonReply(replyPort, 200, { rows: slim });
  }

  // Open to every viewer who reaches the frame. Anyone not on the space's roster (v1's
  // `is_anon`) gets a reduced projection below (no member identities, no notes).
  if (reqPath === "/api/assets" && method === "GET") {
    const { rows } = await assets.query({ limit: 2000 }) as { rows: AssetRow[] };
    rows.sort((a, b) => String(a.name).localeCompare(String(b.name)));

    if (peer.is_anon) {
      // Anonymous: name, item_type, simple status. No member identities, no notes.
      const publicRows = rows.map((r) => {
        const status = computeStatus(r, now);
        const checkedOutAt = toIntOrNull(r.checked_out_at);
        const borrowDays = toIntOrNull(r.borrow_days);
        const due = dueAt(checkedOutAt, borrowDays);
        return {
          _row_id: r._row_id,
          name: r.name,
          item_type: r.item_type,
          status,
          due_at: due,
        };
      });
      return jsonReply(replyPort, 200, { rows: publicRows, anon_view: true });
    }

    // Authenticated: full data + computed status + resolved checkout names.
    const memberRows = await roster();
    const memberById = new Map(memberRows.map((m) => [String(m._row_id), m]));
    const enriched = rows.map((r) => {
      const status = computeStatus(r, now);
      const checkedOutAt = toIntOrNull(r.checked_out_at);
      const borrowDays = toIntOrNull(r.borrow_days);
      const memberId = String(r.checked_out_member_id ?? "");
      const member = memberId ? memberById.get(memberId) : undefined;
      return {
        _row_id: r._row_id,
        _created_at: r._created_at,
        name: r.name,
        item_type: r.item_type,
        checked_out_member_id: memberId,
        checked_out_member_name: member ? String(member.name) : "",
        checked_out_manual_name: String(r.checked_out_manual_name ?? ""),
        checked_out_at: checkedOutAt,
        borrow_days: borrowDays,
        due_at: dueAt(checkedOutAt, borrowDays),
        needs_attention: Number(r.needs_attention) === 1,
        notes: String(r.notes ?? ""),
        status,
      };
    });
    return jsonReply(replyPort, 200, { rows: enriched });
  }

  // ----- Mutations: every POST maps to a bus op (path minus "/api/") and runs through the
  // same handleWrite the bus dispatcher uses — validation and role gates live inside it.
  if (method === "POST" && reqPath.startsWith("/api/")) {
    const r = await handleWrite(peer.sfi_id, reqPath.slice("/api/".length), parseJsonBody(body), peer);
    if (r.status === 204) return replyPort.postMessage({ status: 204, contentType: "text/plain", body: null });
    return jsonReply(replyPort, r.status, r.body);
  }

  if (method === "GET") {
    return serveFileAtPath(replyPort, new URL("./public" + reqPath, import.meta.url));
  }

  // Non-POST mutation methods were never routes; keep the old editor gate + 404 for them.
  if (!editable && reqPath !== "/api/settings") {
    return jsonReply(replyPort, 403, { error: "editing is restricted" });
  }
  replyPort.postMessage({ status: 404, contentType: "application/json", body: JSON.stringify({ error: "Not found.", code: "NOT_FOUND" }) });
};

log("Community Library frame is up and running.");
